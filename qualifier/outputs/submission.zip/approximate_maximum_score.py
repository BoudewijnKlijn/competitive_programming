class ApproximateMaximumScore:
    pass
